package home.project.Game_Center.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Game {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String teamHome;
	private String teamAway;
	private Integer goalHome;
	private Integer goalAway;
	private Integer possessionHome;
	private Integer possessionAway;
	private Integer shotOnGoalHome;
	private Integer shotOnGoalAway;
	private Integer yellowHome;
	private Integer yellowAway;
	private Integer redHome;
	private Integer redAway;
	private Integer faultsHome;
	private Integer faultsAway;
	private Integer passHome;
	private Integer passAway;
	private String date;
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTeamHome() {
		return teamHome;
	}
	public void setTeamHome(String teamHome) {
		this.teamHome = teamHome;
	}
	public String getTeamAway() {
		return teamAway;
	}
	public void setTeamAway(String teamAway) {
		this.teamAway = teamAway;
	}
	public Integer getGoalHome() {
		return goalHome;
	}
	public void setGoalHome(Integer goalHome) {
		this.goalHome = goalHome;
	}
	public Integer getGoalAway() {
		return goalAway;
	}
	public void setGoalAway(Integer goalAway) {
		this.goalAway = goalAway;
	}
	public Integer getPossessionHome() {
		return possessionHome;
	}
	public void setPossessionHome(Integer possessionHome) {
		this.possessionHome = possessionHome;
	}
	public Integer getPossessionAway() {
		return possessionAway;
	}
	public void setPossessionAway(Integer possessionAway) {
		this.possessionAway = possessionAway;
	}
	public Integer getShotOnGoalHome() {
		return shotOnGoalHome;
	}
	public void setShotOnGoalHome(Integer shotOnGoalHome) {
		this.shotOnGoalHome = shotOnGoalHome;
	}
	public Integer getShotOnGoalAway() {
		return shotOnGoalAway;
	}
	public void setShotOnGoalAway(Integer shotOnGoalAway) {
		this.shotOnGoalAway = shotOnGoalAway;
	}
	public Integer getYellowHome() {
		return yellowHome;
	}
	public void setYellowHome(Integer yellowHome) {
		this.yellowHome = yellowHome;
	}
	public Integer getYellowAway() {
		return yellowAway;
	}
	public void setYellowAway(Integer yellowAway) {
		this.yellowAway = yellowAway;
	}
	public Integer getRedHome() {
		return redHome;
	}
	public void setRedHome(Integer redHome) {
		this.redHome = redHome;
	}
	public Integer getRedAway() {
		return redAway;
	}
	public void setRedAway(Integer redAway) {
		this.redAway = redAway;
	}
	public Integer getFaultsHome() {
		return faultsHome;
	}
	public void setFaultsHome(Integer faultsHome) {
		this.faultsHome = faultsHome;
	}
	public Integer getFaultsAway() {
		return faultsAway;
	}
	public void setFaultsAway(Integer faultsAway) {
		this.faultsAway = faultsAway;
	}
	public Integer getPassHome() {
		return passHome;
	}
	public void setPassHome(Integer passHome) {
		this.passHome = passHome;
	}
	public Integer getPassAway() {
		return passAway;
	}
	public void setPassAway(Integer passAway) {
		this.passAway = passAway;
	}
}
