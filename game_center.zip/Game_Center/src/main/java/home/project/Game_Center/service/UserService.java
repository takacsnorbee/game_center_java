package home.project.Game_Center.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import home.project.Game_Center.entity.User;
import home.project.Game_Center.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	private UserRepository ur;
	
	public void saveUser(User user) {
		ur.save(user);
	}
	
	public boolean findByUsername(String username) {
		if(ur.findByUsername(username) == null) {
			return false;
		} else {
			return true;
		}
	}
	
	public User findByUsernameAndPassword(String username, String password) {
		return ur.findByUsernameAndPassword(username, password);
	}
}
