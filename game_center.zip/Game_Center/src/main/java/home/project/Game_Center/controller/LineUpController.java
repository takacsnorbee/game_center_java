package home.project.Game_Center.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
@SessionAttributes(value = {"username","id","admin"})
public class LineUpController {

	@RequestMapping(value = "lineup", method = RequestMethod.GET)
	public String lineUpView(ModelMap model) {
		if (model.getAttribute("username") == null) {
			return "redirect:/login";
		} else {
			//players should came from database, but I did not upload it...
			//And also I should use player id to identify them properly
			String[] players = new String[15];
			for (int i = 0; i < players.length; i++) {
				players[i] = "player " + (i+1);
			}
			model.addAttribute("players", players);
			return "gc_lineup";
		}
	}
	@RequestMapping(value = "lineupPost", method = RequestMethod.POST)
	public String lineUpPost(String gk, String lb, String rb, String cd1, String cd2, String lm,
							String rm, String cm1, String cm2, String st1, String st2) {
		
		System.out.println(gk + " " + lb + " " + rb + " " + cd1  + " " + cd2 + " " + lm + " " +
				rm + " " + cm1 + " " + cm2 + " " + st1 + " " + st2);
		return "redirect:/index";
	}
}
