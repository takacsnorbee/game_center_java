package home.project.Game_Center.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import home.project.Game_Center.entity.Game;
import home.project.Game_Center.service.NewMatchService;

@Controller
@SessionAttributes(value = {"username","id","admin"})
public class StatController {
	
	@Autowired
	private NewMatchService nms;

	@RequestMapping(value = "stat", method = RequestMethod.GET)
	public String statView(ModelMap model, @RequestParam Integer id) {
		
		if (model.getAttribute("username") == null) {
			return "redirect:/login";
		} else {
			model.addAttribute("games", nms.findAllGame());
			if (id != 0) {
				Game thisGame = nms.findById(id);
				//-- order data into rows
				Integer[] statHome = {thisGame.getGoalHome(), thisGame.getPossessionHome(), thisGame.getShotOnGoalHome(), 
						thisGame.getYellowHome(), thisGame.getRedHome(), thisGame.getFaultsHome(), thisGame.getPassHome()};
				String[] label = {"goals", "possession", "shot on goal", "yellow card", "red card", "fault", "pass completed"};
				Integer[] statAway = {thisGame.getGoalAway(), thisGame.getPossessionAway(), thisGame.getShotOnGoalAway(), 
						thisGame.getYellowAway(), thisGame.getRedAway(), thisGame.getFaultsAway(), thisGame.getPassAway()};
				
				List<String[]> statRow = new ArrayList<>();
				
				for (int i = 0; i < label.length; i++) {
					String[] temp = {String.valueOf(statHome[i]), label[i], String.valueOf(statAway[i])};
					statRow.add(temp);
				}
				model.addAttribute("teams", thisGame);
				model.addAttribute("stat", statRow);
			}
			return "gc_stat";
		}
	}
	@RequestMapping(value = "statPost", method = RequestMethod.POST)
	public String statPost(String gamePicked) {
		return "redirect:/stat?id=" + gamePicked;
	}
}
