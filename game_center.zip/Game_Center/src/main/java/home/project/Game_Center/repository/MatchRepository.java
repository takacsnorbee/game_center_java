package home.project.Game_Center.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import home.project.Game_Center.entity.Game;

@Repository
public interface MatchRepository extends JpaRepository<Game, Integer> {

}
