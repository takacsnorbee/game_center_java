package home.project.Game_Center.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import home.project.Game_Center.entity.Player;

@Repository
public interface PlayerRepository extends JpaRepository<Player, Integer> {

	Player findByNameAndPlayerNumber(String name, Integer playerNumber);
	Player findByTeamIdAndPlayerNumber(Integer teamId, Integer playerNumber);
}
