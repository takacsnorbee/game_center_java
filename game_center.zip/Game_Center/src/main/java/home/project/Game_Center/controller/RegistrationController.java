package home.project.Game_Center.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import home.project.Game_Center.entity.User;
import home.project.Game_Center.service.UserService;

@Controller
public class RegistrationController {

	@Autowired
	private UserService us;
	
	@RequestMapping(value = "registration", method = RequestMethod.GET)
	public String registrationView() {
		return "gc_registration";
	}
	
	@RequestMapping(value = "registrationPost", method = RequestMethod.POST)
	public String registrationPost(String regex, User user, Model model) {
		
		if (!regex.equals("wrong")) {
			if (!us.findByUsername(user.getUsername())) {
				us.saveUser(user);
				return "redirect:/login";
			} else {
				model.addAttribute("wrongRegistration", "The username already used.");
				return "gc_registration";
			}
		} else {
			return "gc_registration";
		}
	}
}
