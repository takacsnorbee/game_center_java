package home.project.Game_Center.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import home.project.Game_Center.entity.Game;
import home.project.Game_Center.entity.Player;
import home.project.Game_Center.entity.Team;
import home.project.Game_Center.repository.MatchRepository;
import home.project.Game_Center.repository.PlayerRepository;
import home.project.Game_Center.repository.TeamRepository;

@Service
public class NewMatchService {

	@Autowired
	private TeamRepository tr;
	
	@Autowired
	private PlayerRepository pr;
	
	@Autowired
	private MatchRepository mr;
	
	//---Team-----------------------------------------------------
	// two or more team with the same name not allowed in a championship
	
	public Team findByTeamName(String teamName) {
		return tr.findByTeamName(teamName);
	}
	
	public List<Team> findAllTeam(){
		return tr.findAll(Sort.by(Sort.Direction.DESC, "points"));
	}
	
	public void saveTeam(Team team) {
		tr.save(team);
	}
	
	//---Player------------------------------------------------------
	
	public Player findPlayerNameNumber(String name, Integer playerNumber) {
		return pr.findByNameAndPlayerNumber(name, playerNumber);
	}
	
	public Player findPlayerTeamNumber(Integer teamId, Integer playerNumber) {
		return pr.findByTeamIdAndPlayerNumber(teamId, playerNumber);
	}
	
	public List<Player> findAllPlayer(){
		return pr.findAll();
	}
	
	public List<Player> findAllPlayerSorted(){
		return pr.findAll(Sort.by(Sort.Direction.DESC, "numberOfGoals"));
	}
	
	public void savePlayer(Player player) {
		pr.save(player);
	}
	
	//---Match----------------------------------------------------------
	
	public List<Game> findAllGame(){
		return mr.findAll();
	}
	
	public Game findById(Integer id) {
		return mr.getOne(id);
	}
	
	public void saveMatch(Game match) {
		mr.save(match);
	}
	
}
