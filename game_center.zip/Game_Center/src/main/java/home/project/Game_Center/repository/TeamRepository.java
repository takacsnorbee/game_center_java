package home.project.Game_Center.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import home.project.Game_Center.entity.Team;

@Repository
public interface TeamRepository extends JpaRepository<Team, Integer>{

	Team findByTeamName(String teamName);
}
