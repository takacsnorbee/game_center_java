package home.project.Game_Center.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import home.project.Game_Center.entity.Game;
import home.project.Game_Center.entity.Player;
import home.project.Game_Center.entity.Team;
import home.project.Game_Center.service.NewMatchService;

@Controller
@SessionAttributes(value = {"username","id","admin"})
public class NewGameController {
	
	@Autowired
	private NewMatchService nms;

	@RequestMapping(value = "newMatch", method = RequestMethod.GET)
	public String newGameView(ModelMap model) {
		if (model.getAttribute("admin") == "1") {
			model.addAttribute("teams", nms.findAllTeam());
			model.addAttribute("players", nms.findAllPlayer());
			return "gc_new";
		} else {
			return "redirect:/index";
		}
	}
	@RequestMapping(value = "newMatch", method = RequestMethod.POST)
	public String newGamePost(Integer goalHome, String teamHome, Integer goalAway, String teamAway,
							  Integer[] playerHome, Integer[] playerAway, Integer possessionHome, 
							  Integer possessionAway, Integer shotOnGoalHome, Integer shotOnGoalAway,
							  Integer yellowHome, Integer yellowAway, Integer redHome, Integer redAway,
							  Integer faultsHome, Integer faultsAway, Integer passHome, Integer passAway,
							  String date) {
	
		Team homeTeam = nms.findByTeamName(teamHome);
		Team awayTeam = nms.findByTeamName(teamAway);
		
		//-- UPDATE goals -------------------
		
		homeTeam.setGoalsScored(homeTeam.getGoalsScored() + goalHome);
		homeTeam.setGoalsAgainst(homeTeam.getGoalsAgainst() + goalAway);
		
		awayTeam.setGoalsScored(awayTeam.getGoalsScored() + goalAway);
		awayTeam.setGoalsAgainst(awayTeam.getGoalsAgainst() + goalHome);
		
		//-- UPDATE match results -----------
		
		homeTeam.setMatches(homeTeam.getMatches() + 1);
		awayTeam.setMatches(awayTeam.getMatches() + 1);
		
		if(goalHome > goalAway) {
			homeTeam.setWins(homeTeam.getWins() + 1);
			awayTeam.setDefeats(awayTeam.getDefeats() + 1);
			homeTeam.setPoints(homeTeam.getPoints() + 3);
		} else if(goalHome < goalAway) {
			homeTeam.setDefeats(homeTeam.getDefeats() + 1);
			awayTeam.setWins(awayTeam.getWins() + 1);
			awayTeam.setPoints(awayTeam.getPoints() + 3);
		} else {
			homeTeam.setDraws(homeTeam.getDraws() + 1);
			awayTeam.setDraws(awayTeam.getDraws() + 1);
			homeTeam.setPoints(homeTeam.getPoints() + 1);
			awayTeam.setPoints(awayTeam.getPoints() + 1);
		}
		
		//-- UPDATE players -------------------
		
		for (int i = 0; i < playerHome.length; i++) {
			Player goalScorerHome = nms.findPlayerTeamNumber(homeTeam.getId(), playerHome[i]);
			goalScorerHome.setNumberOfGoals(goalScorerHome.getNumberOfGoals() + 1);
			nms.savePlayer(goalScorerHome);
		}
		
		for (int i = 0; i < playerAway.length; i++) {
			Player goalScorerAway = nms.findPlayerTeamNumber(awayTeam.getId(), playerAway[i]);
			goalScorerAway.setNumberOfGoals(goalScorerAway.getNumberOfGoals() + 1);
			nms.savePlayer(goalScorerAway);
		}
		
		nms.saveTeam(homeTeam);
		nms.saveTeam(awayTeam);
		
		//-- Save match stats ------------------
		
		Game actualGame = new Game();
		actualGame.setTeamHome(teamHome);
		actualGame.setTeamAway(teamAway);
		actualGame.setGoalHome(goalHome);
		actualGame.setGoalAway(goalAway);
		actualGame.setPossessionHome(possessionHome);
		actualGame.setPossessionAway(possessionAway);
		actualGame.setShotOnGoalHome(shotOnGoalHome);
		actualGame.setShotOnGoalAway(shotOnGoalAway);
		actualGame.setYellowHome(yellowHome);
		actualGame.setYellowAway(yellowAway);
		actualGame.setRedHome(redHome);
		actualGame.setRedAway(redAway);
		actualGame.setFaultsHome(faultsHome);
		actualGame.setFaultsAway(faultsAway);
		actualGame.setPassHome(passHome);
		actualGame.setPassAway(passAway);
		actualGame.setDate(date);
		
		nms.saveMatch(actualGame);
		
		return "redirect:/newMatch";
	}
}
