package home.project.Game_Center.bootstrap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import home.project.Game_Center.entity.Game;
import home.project.Game_Center.entity.Player;
import home.project.Game_Center.entity.Team;
import home.project.Game_Center.entity.User;
import home.project.Game_Center.repository.MatchRepository;
import home.project.Game_Center.repository.TeamRepository;
import home.project.Game_Center.repository.UserRepository;

@Component
public class Load implements ApplicationListener<ContextRefreshedEvent> {

	@Autowired
	private UserRepository ur;
	
	@Autowired
	private TeamRepository tr;
	
	@Autowired
	private MatchRepository mr;
	
	@Override
	public void onApplicationEvent(ContextRefreshedEvent event) {
		
		// Add Match
		
		Game baseMatch = new Game();
		baseMatch.setTeamHome("dpse");
		baseMatch.setTeamAway("teamA");
		baseMatch.setGoalHome(1);
		baseMatch.setGoalAway(0);
		baseMatch.setPossessionHome(70);
		baseMatch.setPossessionAway(30);
		baseMatch.setFaultsHome(10);
		baseMatch.setFaultsAway(23);
		baseMatch.setPassHome(245);
		baseMatch.setPassAway(130);
		baseMatch.setRedHome(0);
		baseMatch.setRedAway(0);
		baseMatch.setYellowHome(2);
		baseMatch.setYellowAway(5);
		baseMatch.setShotOnGoalHome(7);
		baseMatch.setShotOnGoalAway(2);
		baseMatch.setDate("2019-11-30");
		
		mr.save(baseMatch);
		
		// Add Users
		
		User admin = new User();
		admin.setUsername("adolf");
		admin.setPassword("123");
		admin.setEmail("email@email.hu");
		admin.setIsAdmin(1);
		
		User baseUser = new User();
		baseUser.setUsername("josef");
		baseUser.setPassword("1234");
		baseUser.setEmail("email@gmail.hu");
		baseUser.setIsAdmin(0);
		
		ur.save(admin);
		ur.save(baseUser);
		
		// Add new Team
		
		Team dpse = new Team();
		dpse.setTeamName("Dpse");
		dpse.setMatches(1);
		dpse.setWins(1);
		dpse.setDraws(0);
		dpse.setDefeats(0);
		dpse.setGoalsScored(1);
		dpse.setGoalsAgainst(0);
		dpse.setPoints(3);
		
		Team teamA = new Team();
		teamA.setTeamName("teamA");
		teamA.setMatches(1);
		teamA.setWins(0);
		teamA.setDraws(0);
		teamA.setDefeats(1);
		teamA.setGoalsScored(0);
		teamA.setGoalsAgainst(1);
		teamA.setPoints(0);
		
		Team teamB = new Team();
		teamB.setTeamName("teamB");
		teamB.setMatches(0);
		teamB.setWins(0);
		teamB.setDraws(0);
		teamB.setDefeats(0);
		teamB.setGoalsScored(0);
		teamB.setGoalsAgainst(0);
		teamB.setPoints(0);
		
		Team teamC = new Team();
		teamC.setTeamName("teamC");
		teamC.setMatches(0);
		teamC.setWins(0);
		teamC.setDraws(0);
		teamC.setDefeats(0);
		teamC.setGoalsScored(0);
		teamC.setGoalsAgainst(0);
		teamC.setPoints(0);
		
		Team teamD = new Team();
		teamD.setTeamName("teamD");
		teamD.setMatches(0);
		teamD.setWins(0);
		teamD.setDraws(0);
		teamD.setDefeats(0);
		teamD.setGoalsScored(0);
		teamD.setGoalsAgainst(0);
		teamD.setPoints(0);
		
		Team teamE = new Team();
		teamE.setTeamName("teamE");
		teamE.setMatches(0);
		teamE.setWins(0);
		teamE.setDraws(0);
		teamE.setDefeats(0);
		teamE.setGoalsScored(0);
		teamE.setGoalsAgainst(0);
		teamE.setPoints(0);
		
		// Add player
		// All available player should be added to the database...
		
		Player basePlayer = new Player();
		basePlayer.setName("Del Piero");
		basePlayer.setNumberOfGoals(1);
		basePlayer.setPlayerNumber(10);
		basePlayer.setTeam(dpse);
		dpse.getPlayers().add(basePlayer);
		
		Player basePlayer1 = new Player();
		basePlayer1.setName("Baggio");
		basePlayer1.setNumberOfGoals(0);
		basePlayer1.setPlayerNumber(9);
		basePlayer1.setTeam(teamE);
		teamE.getPlayers().add(basePlayer1);

		tr.save(dpse);
		tr.save(teamA);
		tr.save(teamB);
		tr.save(teamC);
		tr.save(teamD);
		tr.save(teamE);
	}
}
