package home.project.Game_Center.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import home.project.Game_Center.entity.User;
import home.project.Game_Center.service.UserService;

@Controller
@SessionAttributes(value = {"username","id","admin"})
public class LoginController {
	
	@Autowired
	private UserService us;

	@RequestMapping(value = {"/","login"}, method = RequestMethod.GET)
	public String loginView(SessionStatus session) {
		session.setComplete();
		return "gc_login";
	}
	
	@RequestMapping(value = "loginPost", method = RequestMethod.POST)
	public String loginPost(Model model, String username, String password) {
		User user = us.findByUsernameAndPassword(username, password);
		
		if (user == null) {
			model.addAttribute("wrongLogin", "Wrong username or password");
			return "gc_login";
		} else {
			if (user.getIsAdmin() == 1) {
				model.addAttribute("admin", "1");
			}
			model.addAttribute("username", user.getUsername());
			model.addAttribute("id", user.getId());
			return "redirect:/index";
		}
	}
}
