var regex = /^[A-Za-z0-9]{3,20}$/;
var emailRegex =/(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])/
var button = document.querySelector("button[type]");
var input = document.querySelector("input[type='hidden']");
var validation = false;
var passwordValidation = false;
var emailValidtion = false;

function validator(){
    var username = document.getElementById("username").value;
    var password1 = document.getElementById("password1").value;
    var password2 = document.getElementById("password2").value;
    var email = document.querySelector("input[type='email']");
    
    if (regex.test(username) && regex.test(password1)) {
        validation = true;
    } 
    if(password1 == password2) {
        passwordValidation = true;
    }
    if(emailRegex.test(email)) {
    	emailValidtion = true;
    }
}

button.addEventListener("click", function() {
    validator();
    if(!validation) {
    	input.value = "wrong";
        alert("Invalid username or password. Username and password must be between 3-20 character" +
                "only number or letter allowed!");
    } 
    if(!passwordValidation) {
    	input.value = "wrong";
        alert("The passwords must be equal!");
    } 
    
    if(!emailValidation) {
    	input.value = "wrong";
        alert("This email adress is not valid!");
    }
});