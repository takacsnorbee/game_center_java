// add new player input
var buttonHome = document.getElementById('addNewHomePlayer');
var buttonAway = document.getElementById('addNewAwayPlayer');
var form = document.querySelector("form");

buttonHome.addEventListener("click", function(){
	var input = document.createElement("input");
	input.setAttribute("type", "text");
	input.setAttribute("name","playerHome");
	form.insertBefore(input, buttonHome);
});

buttonAway.addEventListener("click", function(){
	var input = document.createElement("input");
	input.setAttribute("type", "text");
	input.setAttribute("name","playerAway");
	form.insertBefore(input, buttonAway);
});